Env setup for windows

1. Open anaconda prompt
2. Run: conda create -n myNewEnv python=3.8.5
3. Press y when prompted
4. cd to the project directory
5. Run: conda activate myNewEnv
6. Run: python -m pip install jupyter
7. Run: conda install pywin32
8. Press y when prompted
9. Run: pip install -r requirements.txt
10. Run: jupyter notebook


Env setup for ubuntu
1. Open terminal
2. Run: conda create -n myNewEnv python=3.8.5
3. Press y when prompted
4. cd to the project directory
5. Run: conda activate myNewEnv
6. Run: pip install -r requirements.txt
7. Run: jupyter notebook