# to-do-list prototype project

## Introduction

>A list manager prototype project created by the GITtogether team.


## Technologies

> This project contains the followings:
- HTML5
- CSS3
- Javascript
- Jquery
- FontAwesome


## Authors
> Wendy, Huan, Bem








